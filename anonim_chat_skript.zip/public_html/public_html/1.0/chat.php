<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="refresh" content="10">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Chat</title>
  <style type="text/css">
    body{
      padding: 0;margin: 0;
    }
    .chat{
      overflow: hidden;
      font-size: 1.5em;
      /*transform: translate(-50%,-50%);*/
      position: absolute;
      background: transparent;
      border: 2px solid #eee;
      display: block;
      height: 70%;
      width: 80%;
      min-width: 300px;
      min-height: 500px;
      top: 5%;
      left: 5%;
      border-radius: 6px;
      box-shadow: 0px 0px 10px grey;
    }
    input{
      position: absolute;
      bottom: 10%;
      left: 5%;
      width: 30%;
      min-wmesajth: 200px;
      background: #eee;
      border: 2px solmesaj #aaa;
      border-radius: 4px;
      padding: 5px 35px 5px;
      font-weight: 900;
      box-shadow: 0px 0px 4px grey;
    }
    .yaz{margin: 0;
      position: absolute;
      bottom: 4%;
      left: 5%;
      background: #eee;
      border: 2px solid #aaa;
      border-radius: 4px;
      padding: 5px 35px 5px;
      font-weight: 900;
      box-shadow: 0px 0px 4px grey;
    }
  </style>
</head>
<body>
<div class="chat" id="chat">
<?php include 'oxu.php';?>
</div><br><input type="text" id="mesaj" name="mesaj"><br><input type="submit" onclick="mesajYaz(document.getElementById('mesaj').value);document.getElementById('mesaj').value=''" class="yaz" id="yaz" value="yaz">
</body>
</html>
<html>
<head>
<script>
    function setCookie(cname, cvalue) {
  const d = new Date();
  document.cookie = cname + "=" + cvalue;
}

function getCookie(cname) {
  let name = cname + "=";
  let ca = document.cookie.split(';');
  for(let i = 0; i < ca.length; i++) {
    let c = ca[i];
    while (c.charAt(0) == ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}
var otaq = getCookie("otaq");
var id = getCookie("id");
var input = document.getElementById("yaz");
function yenile(id) {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        document.getElementById("chat").innerHTML = this.responseText;
      }
    };
    xmlhttp.open("GET", "oxu.php", true);
    xmlhttp.send();
  }


  
setInterval(yenile,10000);
function mesajYaz(mesaj) {
  if (mesaj.length == 0) {
    document.getElementById("chat").innerHTML = "";
    return;
  } else {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        document.getElementById("chat").innerHTML = this.responseText;
      }
    };
    xmlhttp.open("GET", "yaz.php?mesaj=" + mesaj +"&otaq="+otaq +"&id="+id, true);
    xmlhttp.send();
  }
}
</script>
</head>
<body>