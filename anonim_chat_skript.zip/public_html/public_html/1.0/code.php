<?php

function code($data){$cipher=openssl_get_cipher_methods()[0];
$key="anonim";return openssl_encrypt($data,$cipher,$key,0,1000000000000000);}
function decode($data){$cipher=openssl_get_cipher_methods()[0];
$key="anonim"; return openssl_decrypt($data,$cipher,$key,0,1000000000000000);}

?>