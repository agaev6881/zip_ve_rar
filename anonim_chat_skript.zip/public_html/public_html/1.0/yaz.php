<?php
include "code.php";
$d=date('d');
$H=date('H');
$i=date('i');
$H+=4;if($H>24){$H-=24;$d++;}if($H<10){$H="0".$H;}
?><?php
$mesaj = $_REQUEST["mesaj"];$id = $_COOKIE["_id"];$otaq = $_COOKIE["_room"];$ad=$_COOKIE['_ad'];
if ($mesaj !== "") {
  $file=fopen($otaq."/".date('y_m_d').".php","a+");
$data=code("<a style='border-width:3px 0;border-color:white;border-style:solid;display:block;background:#".$id.";width:100%;'>[".$H.":".$i."] ".$ad." [".$id."] => ".$mesaj."</a>");
  fwrite($file,$data);
  fwrite($file,"\n");
  
}
?>