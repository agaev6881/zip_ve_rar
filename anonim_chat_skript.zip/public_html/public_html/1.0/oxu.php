<?php
include "code.php";
// error_reporting(0);
$otaq = $_COOKIE['_room'];
$fileread=fopen($otaq."/".date('y_m_d').".php","r");
$data=fread($fileread, filesize($otaq."/".date('y_m_d').".php"));
$data=explode("\n",$data);
for ($i=count(file($otaq."/".date('y_m_d').".php"))-1; $i >= 0 ; $i--) { 
echo decode($data[$i]);
}
?>