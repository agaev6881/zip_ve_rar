<?php
include_once("./code.php");
if(!isset($_COOKIE['_id']) OR !isset($_COOKIE['_room']) OR !isset($_COOKIE['_ad'])){echo"<script>alert('Giriş edin');</script><meta http-equiv='refresh'  content='0;login.php'>";die("");}
?><!DOCTYPE html>
<html>
<head>
  <meta http-equiv="refresh" content="999920">
  <meta charset="utf-8">
  <meta id="refresh" name="viewport" content="width=device-width, initial-scale=1">
  <title>Chat</title>
  <style type="text/css">
  
  .name{
      font-weight:500;font-size:90%;font-family:arial;text-shadow:0px 0px 1px #333;
  }
  .oclock{
      font-size:80%;line-height:150%;font-variant:small-caps;
  }
  .anchor{
      margin:0px 0px 2px rbga(0,0,0,.5);box-shadow:0px 1px 3px black;border-radius:6px;border-width:0px 0px 1px 0;border-color:black;border-style:solid;display:block;width:100%;
  }
  .ok{
      user-select:none;
  }
  .copyable{
      font-size:80%;line-height:150%;font-variant:small-caps;
      user-select:auto;}
  .bg{
    height:100%;
    width:100%;
    background:url(https://tse1.mm.bing.net/th?id=OIP.uMqvbVxc2qWOK7TmG-fosgHaEo&pid=Api&P=0);
    filter:blur(15px);
    background-repeat:no-repeat;
    background-position:0 0;
    background-size:100% 100%;
    background-attachment:fixed;
    position:absolute;
    z-index:0;
    margin:0;
}
html,body{
    overflow:hidden;
    height:100%;
    width:100%;
}

img{
    display:none;
}
  #input:invalid{border-color:red;}
    body{
      padding: 0;margin: 0;
    }
    .chat{
      overflow: auto;
      font-size: 1.25em;
      /*transform: translate(-50%,-50%);*/
      position: absolute;
      background: rgba(255,255,255,.7);
      height: 70%;
      border: 2px solid #eee;
      display: block;
      width: 90%;
      min-width: 300px;
      min-height: 300px;
      top: 10%;
      left: 5%;
      border-radius: 6px;
      box-shadow: 0px 0px 10px grey;
    }
    #input{
      position: absolute;
      bottom: 10%;
      left: 5%;
      width: 30%;
      min-width: 200px;
      background: rgba(255,255,255,.6);
      border: 2px solid #aaa;
      border-radius: 4px;
      padding: 5px 35px 5px;
      font-weight: 900;
      box-shadow: 0px 0px 4px grey;
    }
    .yaz{margin: 0;
      position: absolute;
      bottom: 4%;
      left: 5%;
      background: rgba(255,255,255,.9);
      border: 2px solid #aaa;
      border-radius: 4px;
      padding: 5px 35px 5px;
      font-weight: 900;
      box-shadow: 0px 0px 4px grey;
    }
    .h1{
        line-height:140%;
        font-weight:900;
        text-shadow:0px 0px 2px black;
        text-align:center;
        overflow: hidden;
      font-size: 1.2em;
      /*transform: translate(-50%,-50%);*/
      position: absolute;
      background: rgba(255,255,255,0.8);
      border: 2px solid #eee;
      display: block;
      height: 5%;
      width: 90%;
      min-width: 300px;
      min-height: 30px;
      top: 2%;
      left: 5%;
      border-radius: 6px;
      box-shadow: 0px 0px 10px grey;
    }    .h2{
        line-height:140%;
        font-weight:900;
       
        text-align:center;
        overflow: hidden;
      font-size: 1.2em;
      /*transform: translate(-50%,-50%);*/
      position: absolute;
      background: rgba(255,255,255,0.9);
      border: 2px solid #eee;
      display: block;
      height: 5%;
      width: 100px;
      min-height: 30px;
      top: 2%;
      left: 5%;
      border-radius: 6px;
   
    }
    .h2:active{ text-shadow:0px 0px 2px black;
           box-shadow: 0px 0px 10px grey;
    }
  </style>
  
</head>
<body>
    <div class="bg"></div>
<div class="h1">Otaq nömrəsi:<?php echo decode($_COOKIE['_room']);?></div>
<div class="h2" onclick="panelOpen()">Panel</div>
<div id="panel" style="height:0px"></div>
<div class="chat" id="chat">
    <?php include"oxu.php";?>
</div><br><input type="text"id="input" oninput="gozle()" id="mesaj" pattern="[A-Za-z0-9.,:;/]{3,100}" name="mesaj"><br><input type="submit" onclick="mesajYaz(document.getElementById('mesaj').value);document.getElementById('mesaj').value=''" class="yaz" id="yaz" value="yaz">
</body>
<script>
    function setCookie(cname, cvalue) {
  const d = new Date();
  document.cookie = cname + "=" + cvalue;
}

function getCookie(cname) {
  let name = cname + "=";
  let ca = document.cookie.split(';');
  for(let i = 0; i < ca.length; i++) {
    let c = ca[i];
    while (c.charAt(0) == ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}
var otaq = getCookie("otaq");
var id = getCookie("id");
var input = document.getElementById("yaz");
function yenile(id) {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        document.getElementById("chat").innerHTML = this.responseText;
      }
    };
    xmlhttp.open("GET", "oxu.php", true);
    xmlhttp.send();
  }


  
setInterval(yenile,250);
function mesajYaz(mesaj) {
  if (mesaj.length == 0) {
    document.getElementById("chat").innerHTML = "";
    return;
  } else {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        document.getElementById("chat").innerHTML = this.responseText;
      }
    };
    xmlhttp.open("GET", "yaz.php?mesaj=" + mesaj +"&otaq="+otaq +"&id="+id, true);
    xmlhttp.send();
  }
}
var refresh=document.getElementById("refresh").content;
function gozle(){
    refresh+=10;
}
</script>
<script>
</script>
</html>