<?php 
include "code.php";
if(isset($_POST['submit'])){
	$otaq=$_POST['otaq'];
	setcookie('_room',code($otaq));setcookie('_ad',code($_POST['ad']));
	$id=decode($_COOKIE['_id']);
	echo '<meta http-equiv=\'refresh\' content=\'0;url=chat.php\'>';
function folder_exist($folder)
{
    $path = realpath($folder);
    return ($path !== false AND is_dir($path)) ? $path : false;
}if(folder_exist("rooms")===false){mkdir("rooms");}

if(folder_exist("rooms/".$otaq)===false){mkdir("rooms/".$otaq);
$panel=rand(1000,9999);
echo "<script type='text/javascript'>
	 var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        document.body.innerHTML = this.responseText;
      }
    };
    xmlhttp.open('GET', 'yaz.php?s=1&mesaj=' +'Otaq yaradıldı ' +'&otaq='+'".$otaq."' +'&id='+$id+'&panel='+".$panel.", true);
    xmlhttp.send();
    alert('Panel kodu :".$panel."');
</script>";}}
?>

