<?php
include_once("./code.php");
//error_reporting(0);
$otaq = decode($_COOKIE['_room']);
$fileread=fopen("rooms/".$otaq."/".date('y_m_d').".php","r");
$data=fread($fileread, filesize("rooms/".$otaq."/".date('y_m_d').".php"));
$data=explode("\n",$data);
for ($i=count(file("rooms/".$otaq."/".date('y_m_d').".php"))-1; $i >= 0 ; $i--) { 
echo decode($data[$i]);
}
$otaq=code($otaq);
?>