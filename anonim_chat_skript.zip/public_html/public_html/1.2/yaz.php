<?php
include "./code.php";
$d=date('d');
$H=date('H');
$i=date('i');
$H+=4;if($H>=24){$H-=24;$d++;}if($H<10){$H="0".$H;}
?><?php
$mesaj = $_REQUEST["mesaj"];$id = decode($_COOKIE["_id"]);$otaq = decode($_COOKIE["_room"]);$ad=decode($_COOKIE['_ad']);
if ($mesaj !== "") {
  $file=fopen("rooms/".$otaq."/".date('y_m_d').".php","a+");
  fopen("rooms/".$otaq."/"."banned".".txt","a+");
  $admin=fopen("rooms/".$otaq."/"."admin".".txt","a+");
  fopen("rooms/".$otaq."/"."deleted".".txt","a+");
  fopen("rooms/".$otaq."/"."muted".".txt","a+");
  fopen("rooms/".$otaq."/"."users".".txt","a+");
  fopen("rooms/".$otaq."/"."pass".".txt","a+");
  if(isset($_REQUEST['panel'])){
      fwrite($admin,code($_REQUEST['panel']));
  }
$data=code("<a  class='anchor' style='color:#".$id.";'><b class='oclock'>[".$H.":".$i."]</b> <b class='name'>".$ad."</b> <b class='copyable'>[".$id."]</b> => ".$mesaj."</a>");
  fwrite($file,$data);
  fwrite($file,"\n");
  
}
?>