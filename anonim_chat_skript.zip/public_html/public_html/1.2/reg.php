<?php

$data="users.txt";

$time=time();

$past_time=0;

$readdata=@fopen($data,"a+") or die("$data faylinin acilmasinda sehv oldu");

$data_array=file($data);

@fclose($readdata);

if(getenv('HTTP_X_FORWARDED_FOR'))

$user = getenv('HTTP_X_FORWARDED_FOR');

else

$user = getenv('REMOTE_ADDR');

$agent = getenv('HTTP_USER_AGENT');

$d=count($data_array);

for($i=0;$i<$d;$i++)

{

list($live_agent,$live_user,$last_time)=explode("::","$data_array[$i]");

if($live_user!=""&&$last_time!=""&&$live_agent!=""):

if($last_time<$past_time):

$live_user="";

$last_time="";

$live_agent="";

endif;

if($live_user!=""&&$last_time!=""&&$live_agent!="")

{

if($user==$live_user&&$agent==$live_agent)

{

$online_array[]="$agent::$user::$time\r\n";

}

else

$online_array[]="$live_agent::$live_user::$last_time";

}

endif;

}

if(isset($online_array)):

foreach($online_array as $i=>$str)

{

if($str=="$agent::$user::$time\r\n")

{

$ok=$i;

break;

}

}

foreach($online_array as $j=>$str)

{

if($ok==$j) { $online_array[$ok]="$agent::$user::$time\r\n"; break;}

}

endif;

$writedata=@fopen($data,"w") or die("$data faylinin acilmasinda sehv oldu");

@flock($writedata,2);

if($online_array=="") $online_array[]="$agent::$user::$time\r\n";

foreach($online_array as $str)

fputs($writedata,"$str");

@flock($writedata,3);

@fclose($writedata);

$readdata=@fopen($data,"a+") or die("$data faylinin acilmasinda sehv oldu");

$data_array=@file($data);

@fclose($readdata);

$online=count($data_array);

echo "<div class='tableni yaz'><center><font color='red'>Online: </font><b><font color='black'> ".$online." </font></b></a> <font color='red'>Nefer</font></center></div>";
echo readfile('users.txt');
?>

