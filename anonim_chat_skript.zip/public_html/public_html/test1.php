<?php
$s=getmac();
print_r();