<?php error_reporting(0);
if(!isset($_COOKIE['_id'])){ setcookie('_id',rand(100000,999999));echo "<meta http-equiv='refresh' content='0'";}?><!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Login</title>
  <style type="text/css">
    [readonly]{
  color: white;   background: #666;
    }
  </style>
<script>function setCookie(cname, cvalue) {
  const d = new Date();
  document.cookie = cname + "=" + cvalue;
}

function getCookie(cname) {
  let name = cname + "=";
  let ca = document.cookie.split(';');
  for(let i = 0; i < ca.length; i++) {
    let c = ca[i];
    while (c.charAt(0) == ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}

function checkCookie() {
  let user = getCookie("username");
  if (user != "") {
    alert("Welcome again " + user);
  } else {
    user = prompt("Please enter your name:", "");
    if (user != "" && user != null) {
      setCookie("username", user, 365);
    }
  }
}</script>
</head>
<body>
  <form action="main.php" method="post">
  <table>
    <tr><?php ob_start();?>
      <td><label>Id</label></td><?php $random=rand(10000,99999);
      if(!isset($_COOKIE['_id'])){setcookie('_id','".$random."'); }else {$random=$_COOKIE['_id'];}?>
      <td><input   type="number" style="border-radius: 4px;background: #666;color:white;" readonly name="id" value="<?php if(!isset($_COOKIE['_id'])){}else echo $random; ?>"></td>
    </tr>
    <?php ob_flush();?>
    <tr>
      <td><label>Ad</label></td>
      <td><input <?php if(isset($_COOKIE['_ad'])){ echo "readonly "." value=".$_COOKIE['_ad'];}?>  style="border-radius: 4px;" required="required" type="text" name="ad"></td>
    </tr>
    <tr>
      <td><label>Otaq</label></td>
      <td><input style="border-radius: 4px;" required="required" type="number" name="otaq"></td>
    </tr>
    <tr>
      <td colspan="2" rowspan="2" ><input  style="display: block;text-align: center;background: #666;color: white;border-radius: 4px;width: 100%;border-color: transparent;" type="submit" value="Gir" name="submit"></td>
    </tr>


</table></form>
</body>
</html>
