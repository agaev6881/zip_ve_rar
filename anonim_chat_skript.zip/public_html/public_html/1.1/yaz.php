<?php
include "code.php";
$d=date('d');
$H=date('H');
$i=date('i');
$H+=4;if($H>24){$H-=24;$d++;}if($H<10){$H="0".$H;}
?><?php
$mesaj = $_REQUEST["mesaj"];$id = $_COOKIE["_id"];$otaq = $_COOKIE["_room"];$ad=$_COOKIE['_ad'];
if ($mesaj !== "") {
  $file=fopen($otaq."/".date('y_m_d').".php","a+");
$data=code("<a style='border-radius:6px;border-width:0px 0px 1px 0;border-color:black;border-style:solid;display:block;color:#".$id.";width:100%;'><b style='font-size:80%;line-height:150%;font-variant:small-caps;'>[".$H.":".$i."]</b> <b style='font-weight:500;font-size:90%;font-family:arial;text-shadow:0px 0px 1px #333;'>".$ad."</b> <b style='font-size:80%;line-height:150%;font-variant:small-caps;'>[".$id."]</b> => ".$mesaj."</a>");
  fwrite($file,$data);
  fwrite($file,"\n");
  
}
?>