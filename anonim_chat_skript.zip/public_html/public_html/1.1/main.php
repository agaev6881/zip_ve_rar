<?php 
if(isset($_POST['submit'])){
	$otaq=$_POST['otaq'];
	setcookie('_room',$otaq);setcookie('_ad',$_POST['ad']);
	$id=$_COOKIE['_id'];
	echo '<meta http-equiv=\'refresh\' content=\'0;url=chat.php\'>';
function folder_exist($folder)
{
    // Get canonicalized absolute pathname
    $path = realpath($folder);

    // If it exist, check if it's a directory
    return ($path !== false AND is_dir($path)) ? $path : false;
}
if(folder_exist($otaq)===false){mkdir($otaq);
echo "<script type='text/javascript'>
	 var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        document.body.innerHTML = this.responseText;
      }
    };
    xmlhttp.open('GET', 'yaz.php?s=1&mesaj=' +'Otaq yaradıldı ' +'&otaq='+'".$otaq."' +'&id='+$id, true);
    xmlhttp.send();
</script>";}}
?>

