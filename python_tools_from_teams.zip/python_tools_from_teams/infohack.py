#!/usr/bin/python3

import os
import time
import platform
import random
import datetime
#Mor = '\033[95m'
#Cyan = '\033[96m'
#KoyuMavi = '\033[1;34m'
#Mavi = '\033[94m'
#Yeşil = '\033[92m'
#Sarı = '\033[93m'
#Pembe = '\33[95m'
#Kırmızı = '\033[91m'
#Kalın = '\033[1m'
#AltıÇizili = '\033[4m'
#Bitir = '\033[0m'
#Beyaz ='\033[1;37m'
#GriKarala = '\33[100m'
#KırmızıKarala='\033[101m'
#YeşilKarala='\33[102m'
#SarıKarala='\33[103m'
#MorKarala='\33[104m'
#PembeKarala = '\33[105m'
#CyanKarala = '\33[106m'
#BeyazKarala = '\33[107m'
print("""\033[94m
██████████████████████████████
██████████████████████████████
""" + """\033[91m██████████████████████████████
██████████████████████████████
""" + """\033[92m██████████████████████████████
██████████████████████████████
   CREATED BY WOSTAREX
  ||info yığma toolu||
=========================  
{1}==nömrədən məlumat  yığma
{2}==hedef web siteden melumat yığma
""")
info = input("seçim edin:")
if(info == "1"):
    numara = input("nömreni yazın:")
ölkəkodu = input("[+-bu olmadan]ölkə kodunu yazın:")
if(ölkəkodu == "994"):
    print("=============================")
print("Azərbaycan nömre:")    
secenekler = ["Azercell GSM", "Bakcell GSM"]
secilen_secenek = random.choice(secenekler)
print("carrier:", secilen_secenek)
print("ölkə kodu:" + ölkəkodu)
print("ölkə:" + "Azərbaycan")
print("nömre:" + numara)

if(ölkəkodu == "90"):
    print("=============================")
print("Türkiye nömre:")   
secenekler = ["Turkcell", "Vodafone", "Türk Telekom"]
secilen_secenek = random.choice(secenekler)
print("carrier:", secilen_secenek)
print("ölkə kodu:" + ölkəkodu)
print("ölkə:" + "Türkiye")
print("nömre:" + numara)
print("2-ci tool:")
web = input("web site:")
url = input("saytın uzantısını yazın(com/az/tr/gov/vs.):")
print("url:" + web)
from random import randint


def generate_random_ip():
    return '.'.join(
        str(randint(0, 255)) for _ in range(4)
    )


random_ip = generate_random_ip()
print("ip:" + random_ip) 
print("url uzantısı:" + url)