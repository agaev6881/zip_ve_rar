<style>
@media only screen and (max-width:600px){
   body{
      margin: 0;
      padding: 0;
        background:url(wall1.jfif);
        background-repeat:no-repeat;
        background-size:100vw 100vh;
        background-position: 0px 7%;
    }
} 
</style>