<?php 
if (!file_exists("baglanti.php")){
		require("install.php");
		die;
	}
include "baglanti.php";
session_start(); //session işlemini başlatıyoruz.
if(!isset($_SESSION['uyeid']))//session varmı die kontrol ediyoruz. yok ise buraya giricek
{
	header("Location:giris.php");//eğer session yok ise bizi giris.php gönderecek.
}
$kullanicisor=$db->prepare("SELECT * FROM uye where id=1");
$kullanicisor->execute();
$kullanicicek=$kullanicisor->fetch(PDO::FETCH_ASSOC);
if ($_POST) {
  if ($_POST['sifre'] == null) {

	  $kullanicikaydet=$db->prepare("UPDATE uye SET
	    adsoyad=:adsoyad,
	    eposta=:eposta
	    WHERE id=1");

	  $adsoyad = htmlspecialchars($_POST['adsoyad']);
	  $eposta = htmlspecialchars($_POST['eposta']);
	  $update=$kullanicikaydet->execute(array(
	    'adsoyad' => $adsoyad,
	    'eposta' => $eposta));


	  if ($update) {
	  	?>
	  		<div>
			<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
			<script type="text/javascript">
				Swal.fire({
  icon: 'success',
  title: 'Bilgiler düzenlendi',
  text: 'Bilgiler başarıyla düzenlendi.',
  showConfirmButton: false
})

			</script>
			</div>
	  	<?php
	    header("refresh: 3; url=uye-duzenle.php");

	  } else {
	  	?>
	  		<div>
			<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
			<script type="text/javascript">
				Swal.fire({
  icon: 'error',
  title: 'Bilgiler düzenlenemedi',
  text: 'Bilgiler düzenlenirken bir hata oluştu.',
  showConfirmButton: false
})

			</script>
			</div>
	  	<?php
	    header("refresh: 3; url=uye-duzenle.php");
	  }
  }
  else
  {
  		$pass=md5($_POST['sifre']);
  		$kullanicikaydet=$db->prepare("UPDATE uye SET
	    adsoyad=:adsoyad,
	    eposta=:eposta,
	    sifre=:sifre,
	    WHERE id=:id");

	  $update=$kullanicikaydet->execute(array(
	    'adsoyad' => $_POST['adsoyad'],
	    'sifre' => $pass,
	    'eposta' => $_POST['eposta'],
	    'id' => $id));


	  if ($update) {
	  	?>
	  		<div>
			<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
			<script type="text/javascript">
				Swal.fire({
  icon: 'success',
  title: 'Bilgiler düzenlendi',
  text: 'Bilgiler başarıyla düzenlendi.',
  showConfirmButton: false
})

			</script>
			</div>
	  	<?php
	    header("refresh: 3; url=uye-duzenle.php");

	  } else {
	  		?>
	  		<div>
			<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
			<script type="text/javascript">
				Swal.fire({
  icon: 'error',
  title: 'Bilgiler düzenlenemedi',
  text: 'Bilgiler düzenlenirken bir hata oluştu.',
  showConfirmButton: false
})

			</script>
			</div>
	  	<?php
	    header("refresh: 3; url=uye-duzenle.php");
	  }
  }
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>MyLisans - Panel</title>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/font-awesome.min.css" rel="stylesheet">
	<link href="css/datepicker3.css" rel="stylesheet">
	<link href="css/styles.css" rel="stylesheet">
	
	<!--Custom Font-->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
	<!--[if lt IE 9]>
	<script src="js/html5shiv.js"></script>
	<script src="js/respond.min.js"></script>
	<![endif]-->
	 <style type="text/css">
					.swal2-popup {
  font-size: 1.6rem !important;
}

				</style>
</head>
<body>
	<nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#sidebar-collapse"><span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span></button>
				<a class="navbar-brand" href="index.php"><span>My</span>Lisans</a>
			</div>
		</div><!-- /.container-fluid -->
	</nav>
	<?php include "sidebar.php"; ?>
		
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Kullanıcı Düzenle</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Kullanıcı Düzenle</h1>
			</div>
		</div><!--/.row-->
		
		<div class="panel panel-container">
			<div class="row">
			<center>
				<form action="" method="POST">
                <div class="form-group">
                  <label>Ad Soyad</label>
                  <input  type="text" style="width: 750px;" name="adsoyad" class="form-control" value="<?php echo $kullanicicek['adsoyad']; ?>" required="required">
                </div>

                <div class="form-group">
                  <label>E-posta</label>
                  <input type="email" style="width: 750px;" name="eposta" value="<?php echo $kullanicicek['eposta']; ?>" class="form-control">
                </div>

                <div class="form-group">
                  <label>Yeni Şifre (Değiştirmeyecekseniz boş bırakın.)</label>
                  <input type="password" style="width: 750px;" name="sifre" class="form-control">
                </div>
                <input type="hidden" name="id" value="1">
                <button type="submit" class="btn btn-primary">Kaydet</button><br>
              </form>
			</center>
			</div><!--/.row-->
		</div>

			<div class="col-sm-12">
				<p class="back-link">Lumino Theme by <a href="https://www.medialoot.com">Medialoot</a></p>
			</div>
		</div><!--/.row-->
	</div>	<!--/.main-->
	
	<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/chart.min.js"></script>
	<script src="js/chart-data.js"></script>
	<script src="js/easypiechart.js"></script>
	<script src="js/easypiechart-data.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script src="js/custom.js"></script>
	<script>
		window.onload = function () {
	var chart1 = document.getElementById("line-chart").getContext("2d");
	window.myLine = new Chart(chart1).Line(lineChartData, {
	responsive: true,
	scaleLineColor: "rgba(0,0,0,.2)",
	scaleGridLineColor: "rgba(0,0,0,.05)",
	scaleFontColor: "#c5c7cc"
	});
};
	</script>
		
</body>
</html>