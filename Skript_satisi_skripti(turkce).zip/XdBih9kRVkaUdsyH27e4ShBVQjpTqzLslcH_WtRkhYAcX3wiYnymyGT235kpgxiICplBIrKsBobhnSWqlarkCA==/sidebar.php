<?php 
include "baglanti.php";
$kullanicisor=$db->prepare("SELECT * FROM uye where id=1");
$kullanicisor->execute();
$kullanicicek=$kullanicisor->fetch(PDO::FETCH_ASSOC);
?>
<div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">
		<div class="profile-sidebar">
			<div class="profile-userpic">
				<img src="https://www.loscanis.com.tr/wp-content/uploads/user.png" class="img-responsive" alt="">
			</div>
			<div class="profile-usertitle">
				<div class="profile-usertitle-name"><?php echo $kullanicicek['adsoyad']; ?></div>
				<div class="profile-usertitle-status"><span class="indicator label-success"></span>Lisansör</div>
			</div>
			<div class="clear"></div>
		</div>
		<div class="divider"></div>
		<ul class="nav menu">
			<li><a href="index.php"><em class="fa fa-dashboard">&nbsp;</em> Panel</a></li>
			<li class="parent "><a data-toggle="collapse" href="#lisanslar">
				<em class="fa fa-navicon">&nbsp;</em> Lisanslar <span data-toggle="collapse" href="#sub-item-1" class="icon pull-right"><em class="fa fa-plus"></em></span>
				</a>
				<ul class="children collapse" id="lisanslar">
					<li><a class="" href="lisanslar.php">
						<span class="fa fa-arrow-right">&nbsp;</span> Lisans İşlemleri
					</a></li>
					<li><a class="" href="lisans-ekle.php">
						<span class="fa fa-arrow-right">&nbsp;</span> Lisans Ekle
					</a></li>
					<li><a class="" href="ihbarlar.php">
						<span class="fa fa-arrow-right">&nbsp;</span> İhbarlar
					</a></li>
				</ul>
			</li>
			<li class="parent "><a data-toggle="collapse" href="#diger">
				<em class="fa fa-navicon">&nbsp;</em> Diğer Araçlar <span data-toggle="collapse" href="#sub-item-1" class="icon pull-right"><em class="fa fa-plus"></em></span>
				</a>
				<ul class="children collapse" id="diger">
					<li><a class="" href="footer-lisans.php">
						<span class="fa fa-arrow-right">&nbsp;</span> Footer Lisanslama
					</a></li>
					<li><a class="" href="https://phpkoru.com/">
						<span class="fa fa-arrow-right">&nbsp;</span> PHP Şifreleme
					</a></li>
				</ul>
			</li>
			<li class="parent "><a data-toggle="collapse" href="#lisansorislem">
				<em class="fa fa-navicon">&nbsp;</em> Kullanıcı İşlemleri <span data-toggle="collapse" href="#sub-item-1" class="icon pull-right"><em class="fa fa-plus"></em></span>
				</a>
				<ul class="children collapse" id="lisansorislem">
					<li><a class="" href="uye-duzenle.php">
						<span class="fa fa-arrow-right">&nbsp;</span> Kullanıcı Düzenle
					</a></li>
				</ul>
			</li>
			<li><a href="sinif-olustur.php"><em class="fa fa-cogs">&nbsp;</em> Koruma sınıfı oluştur</a></li>
			<li><a href="denemesuresi.php"><em class="fa fa-cogs">&nbsp;</em> Deneme süresi ayala</a></li>
			<li><a href="cikis.php"><em class="fa fa-power-off">&nbsp;</em> Güvenli Çıkış</a></li>
		</ul>
	</div><!--/.sidebar-->