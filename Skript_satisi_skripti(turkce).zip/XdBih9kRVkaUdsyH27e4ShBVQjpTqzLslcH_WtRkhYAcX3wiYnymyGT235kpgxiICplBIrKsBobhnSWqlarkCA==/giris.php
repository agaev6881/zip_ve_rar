<?php
session_start();
include "baglanti.php";
if($_POST){
		$eposta = $_POST["eposta"];
		$sifre = md5($_POST["sifre"]);
		$kullanicisor=$db->prepare("SELECT * FROM uye WHERE eposta=? and sifre=?");
		$kullanicisor->execute(array($eposta,$sifre));
		$islem=$kullanicisor->fetch();
		
		if($islem){
			$_SESSION['eposta'] = $islem['eposta'];
			$_SESSION['adsoyad'] = $islem['adsoyad'];
			$_SESSION['uyeid'] = $islem['id'];
			?>
			<div>
			<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
			<script type="text/javascript">
				Swal.fire({
  icon: 'success',
  title: 'Giriş Başarılı',
  text: 'Hoşgeldiniz, yönlendiriliyorsunuz..',
  showConfirmButton: false
})

			</script>
			</div>
			<meta http-equiv="refresh" content="3;URL=index.php">			
			<?php
		} else{
			?>
			<div>
			<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
			<script type="text/javascript">swal.fire("Giriş Hatalı!", "Bilgileriniz hatalı! Tekrar deneyiniz.", "error");
			</script>
			</div>
			<?php
		} 
	}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>MyLisans - Giriş</title>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/datepicker3.css" rel="stylesheet">
	<link href="css/styles.css" rel="stylesheet">
	<!--[if lt IE 9]>
	<script src="js/html5shiv.js"></script>
	<script src="js/respond.min.js"></script>
	<![endif]-->
	 <style type="text/css">
					.swal2-popup {
  font-size: 1.6rem !important;
}

				</style>
</head>
<body>
	<div class="row">
		<div class="col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2 col-md-4 col-md-offset-4">
			<div class="login-panel panel panel-default">
				<div class="panel-heading">MyLisans - Giriş Yap</div>
				<div class="panel-body">
					<form action="" method="POST" role="form">
						<fieldset>
							<div class="form-group">
								<input class="form-control" placeholder="E-Posta" name="eposta" type="email" autofocus="">
							</div>
							<div class="form-group">
								<input class="form-control" placeholder="Şifre" name="sifre" type="password">
							</div>
							<button type="submit" class="btn btn-primary">Giriş Yap</button></fieldset>
					</form>
				</div>
			</div>
		</div><!-- /.col-->
	</div><!-- /.row -->	
	

<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
</body>
</html>
