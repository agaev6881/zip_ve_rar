<?php 
include "baglanti.php";

session_start(); //session işlemini başlatıyoruz.
if(!isset($_SESSION['uyeid']))//session varmı die kontrol ediyoruz. yok ise buraya giricek
{
	header("Location:giris.php");//eğer session yok ise bizi giris.php gönderecek.
}

$sure = $db->prepare("SELECT * FROM ayar");
$sure->execute();
$fetched = $sure->fetch();

if (isset($_POST['kapat'])) {
	$tabloya_ekle2 = $db->prepare("UPDATE ayar SET trialtime=0");
        $tabloya_ekle2->execute();
          ?>
          <div>
			<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
			<script type="text/javascript">
				Swal.fire({
  icon: 'warning',
  title: 'Uyarı',
  text: 'Deneme süresi kapatıldı fakat scriptinize yazdığınız koruma sınıfını tekrardan güncellemeniz gereklidir.',
  showConfirmButton: false
})

			</script>
			</div>
			<?php
          echo '<meta http-equiv="refresh" content="3;URL=denemesuresi.php">';
}

if (isset($_POST['baslat'])) {
	$tabloya_ekle1 = $db->prepare("UPDATE ayar SET trialtime=1");
        $tabloya_ekle1->execute();
          ?>
          <div>
			<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
			<script type="text/javascript">
				Swal.fire({
  icon: 'warning',
  title: 'Uyarı',
  text: 'Deneme süresi açıldı fakat scriptinize yazdığınız koruma sınıfını tekrardan güncellemeniz gereklidir.',
  showConfirmButton: false
})

			</script>
			</div>
			<?php
          echo '<meta http-equiv="refresh" content="3;URL=denemesuresi.php">';
}

if (isset($_POST['ayarla'])) {
$trial=$_POST["trial"];

$tabloya_ekle = $db->prepare("UPDATE ayar SET trialtime=?");
        $tabloya_ekle->execute(array($trial));
          ?>
          <div>
			<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
			<script type="text/javascript">
				Swal.fire({
  icon: 'success',
  title: 'Deneme süresi ayarlandı',
  text: 'Artık scriptiniz kurulduktan sonra <?php echo $trial; ?> gün boyunca lisans istemenden çalışacak.',
  showConfirmButton: false
})

			</script>
			</div>
			<?php
          echo '<meta http-equiv="refresh" content="3;URL=denemesuresi.php">';
}

 ?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>MyLisans - Panel</title>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/font-awesome.min.css" rel="stylesheet">
	<link href="css/datepicker3.css" rel="stylesheet">
	<link href="css/styles.css" rel="stylesheet">
	
	<!--Custom Font-->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
	<!--[if lt IE 9]>
	<script src="js/html5shiv.js"></script>
	<script src="js/respond.min.js"></script>
	<![endif]-->
	 <style type="text/css">
					.swal2-popup {
  font-size: 1.6rem !important;
}

				</style>
</head>
<body>
	<nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#sidebar-collapse"><span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span></button>
				<a class="navbar-brand" href="index.php"><span>My</span>Lisans</a>
			</div>
		</div><!-- /.container-fluid -->
	</nav>
	<?php include "sidebar.php"; ?>
		
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Deneme süresi ayarla</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Deneme süresi ayarla</h1>
			</div>
		</div><!--/.row-->
		
		<div class="panel panel-container">
			<div class="row">
			<center>
				<div class="col-md-12">
				<div class="panel panel-blue">
					<div class="panel-heading dark-overlay">Deneme süresi nedir?</div>
					<div class="panel-body">
						<p>Deneme süresi sistemi, scriptinizin lisanssız olarak belirli bir süre boyunca kullanılmasını sağlar.</p><br>
						<b>UYARI ! Özelliği kapatınca veya açınca yeniden koruma sınıfı oluştup, sınıfı scriptinizin en önemli dosyasının (örnek: fonksiyon.php) başına yapıştırıp şifreleyin.</b>
					</div>
				</div>
			</div><!--/.col-->
			<?php if (!empty($fetched['trialtime'])){ ?>
				<form action="" method="POST" role="form">
				<div class="form-group">
					<label>Deneme süresi</label><br>
					<input value="<?php echo $fetched['trialtime']; ?>" style="width: 75px; display: inline;" class="form-control" name="trial" type="number" > <h3 style="display: inline;">/gün</h3>
				</div>
				<div class="form-group">
					<button type="submit" name="ayarla" class="btn btn-primary" >Ayarla</button>
				</div>
				<div class="form-group">
					<button name="kapat" type="submit" class="btn btn-danger" >Özelliği Kapat</button>
				</div>
				
			</form>		
		<?php }else{ ?>
			<form action="" method="POST">
					<div class="form-group">
					<button name="baslat" type="submit" class="btn btn-success" >Özelliği Aç</button>

				</div></form>
				<?php } ?>	
			</center>
			</div><!--/.row-->
		</div>

			<div class="col-sm-12">
				<p class="back-link">Lumino Theme by <a href="https://www.medialoot.com">Medialoot</a></p>
			</div>
		</div><!--/.row-->
	</div>	<!--/.main-->
	
	<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/chart.min.js"></script>
	<script src="js/chart-data.js"></script>
	<script src="js/easypiechart.js"></script>
	<script src="js/easypiechart-data.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script src="js/custom.js"></script>
	<script>
		window.onload = function () {
	var chart1 = document.getElementById("line-chart").getContext("2d");
	window.myLine = new Chart(chart1).Line(lineChartData, {
	responsive: true,
	scaleLineColor: "rgba(0,0,0,.2)",
	scaleGridLineColor: "rgba(0,0,0,.05)",
	scaleFontColor: "#c5c7cc"
	});
};
	</script>
		
</body>
</html>