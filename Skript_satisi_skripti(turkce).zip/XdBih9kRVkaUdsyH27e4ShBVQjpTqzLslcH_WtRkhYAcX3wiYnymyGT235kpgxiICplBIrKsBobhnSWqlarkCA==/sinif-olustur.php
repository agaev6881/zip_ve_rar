<?php session_start(); //session işlemini başlatıyoruz.
if(!isset($_SESSION['uyeid']))//session varmı die kontrol ediyoruz. yok ise buraya giricek
{
	header("Location:giris.php");//eğer session yok ise bizi giris.php gönderecek.
} 
include "baglanti.php";
$sure = $db->prepare("SELECT * FROM ayar");
$sure->execute();
$fetched = $sure->fetch();
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>MyLisans - Panel</title>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/font-awesome.min.css" rel="stylesheet">
	<link href="css/datepicker3.css" rel="stylesheet">
	<link href="css/styles.css" rel="stylesheet">
	
	<!--Custom Font-->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
	<!--[if lt IE 9]>
	<script src="js/html5shiv.js"></script>
	<script src="js/respond.min.js"></script>
	<![endif]-->
	 <style type="text/css">
					.swal2-popup {
  font-size: 1.6rem !important;
}

				</style>
				<style>
code {
    padding: 2px 4px;
    font-size: 90%;
    color: #c7254e;
    background-color: #f9f2f4;
    border-radius: 4px;
}
</style>
</head>
<body>
	<nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#sidebar-collapse"><span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span></button>
				<a class="navbar-brand" href="index.php"><span>My</span>Lisans</a>
			</div>
		</div><!-- /.container-fluid -->
	</nav>
	<?php include "sidebar.php"; ?>
		
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Koruma Sınıfı Oluştur</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Koruma Sınıfı Oluştur</h1>
			</div>
		</div><!--/.row-->
		
		<div class="panel panel-container">
			<div class="row">
			<center>
			<div class="col-md-12">
				<div class="panel panel-blue">
					<div class="panel-heading dark-overlay">Koruma sınıfı nedir?</div>
					<div class="panel-body">
						<p>Koruma sınıfı, lisansı doğrulayan ufak kod parçasıdır. <br><br> <b>Bu kodu scriptinizin fonksiyon.php gibi en önemli dosyasının başına yapıştırıp, dosyayı şifreleyin.</b></p>
					</div>
				</div>
			</div><!--/.col-->
			</center>
			<div class="col-md-12">
				<div class="panel panel-success">
					<div class="panel-heading">Yey! Koruma sınıfınız oluşturuldu!</div>
					<div class="panel-body">
						<?php $urll = "http".(!empty($_SERVER['HTTPS'])?"s":"").
"://".$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'];
$url = substr($urll, 0, -17);
if (empty($fetched['trialtime'])) {
 ?>
						<p><textarea onclick="this.focus();this.select()" class="form-control" rows="12" readonly="" style="display: inline;">
&lt?php 
function get_custom_date($timezone = "UTC", $format = "d.m.Y, H:i:s") {
 $dt = new DateTime("now", new DateTimeZone($timezone));
 $dt->setTimestamp(time());
 return $dt->format($format);
 unset($timezone, $format, $dt);
}

$checker = file_get_contents('<?php echo $url; ?>api/checker.php?domain=' . $_SERVER["HTTP_HOST"] .'');

$json = json_decode($checker);

$mylisans_timezone = "Europe/Istanbul";
$bitisraw = $json->bitis;
$bitisarray = explode("-", $bitisraw);
$bitis = mktime(0, 0, 0, $bitisarray[1], $bitisarray[2], $bitisarray[0]);
$tarih = mktime(0, 0, 0, get_custom_date($mylisans_timezone, "m") , get_custom_date($mylisans_timezone, "d") , get_custom_date($mylisans_timezone, "Y"));

$adsoyad = $json->adsoyad;
$status = $json->status;
$ban = $json->ban;

if ($status == "error") {
    ?>
  &lt;iframe width="0" frameborder="no" height="0" src="<?php echo $url; ?>api/ihbar.php?domain=&lt;?php echo $_SERVER['SERVER_NAME'] ?>">&lt;/iframe>
  &lt;?php
die("<!DOCTYPE html>
<html>
<head>
    <title>Lisans hatası!</title>
    <link href=\"https://fonts.googleapis.com/css?family=Didact+Gothic|Montserrat|Open+Sans+Condensed:300|Titillium+Web&display=swap\" rel=\"stylesheet\">
    <style type=\"text/css\">
        body {
            background-color: #FF3B3B;
            font-family: 'Didact Gothic', sans-serif;
            color: white;
        }
    </style>
</head>
<body>
<center>
    <br><br><br>
    <img width=\"215\" height=\"200\" src=\"https://img510.yukle.tc/images/6935alert.png\">
    <h2>Lisans hatası aldınız!</h2><br><br>
    <h3>Bu hatayı neden aldınız?</h3>
    <h4>Scripti lisanssız kurmuşsunuz. Lisans satın almanız gereklidir.</h4>
</center>
</body>
</html>");
}else{
    if ($bitis < $tarih) {
        die("
<!DOCTYPE html>
<html>
<head>
    <title>Lisans hatası!</title>
    <link href=\"https://fonts.googleapis.com/css?family=Didact+Gothic|Montserrat|Open+Sans+Condensed:300|Titillium+Web&display=swap\" rel=\"stylesheet\">
    <style type=\"text/css\">
        body {
            background-color: #FF3B3B;
            font-family: 'Didact Gothic', sans-serif;
            color: white;
        }
    </style>
</head>
<body>
<center>
    <br><br><br>
    <img width=\"215\" height=\"200\" src=\"https://img510.yukle.tc/images/6935alert.png\">
    <h2>Lisans hatası aldınız!</h2><br><br>
    <h3>Bu hatayı neden aldınız?</h3>
    <h4>Lisans süreniz dolmuştur. Yeni lisans almanız gereklidir.</h4>
</center>
</body>
</html>
            ");
    }else{
        if ($ban) {
            die("
<!DOCTYPE html>
<html>
<head>
    <title>Lisans hatası!</title>
    <link href=\"https://fonts.googleapis.com/css?family=Didact+Gothic|Montserrat|Open+Sans+Condensed:300|Titillium+Web&display=swap\" rel=\"stylesheet\">
    <style type=\"text/css\">
        body {
            background-color: #FF3B3B;
            font-family: 'Didact Gothic', sans-serif;
            color: white;
        }
    </style>
</head>
<body>
<center>
    <br><br><br>
    <img width=\"215\" height=\"200\" src=\"https://img510.yukle.tc/images/6935alert.png\">
    <h2>Lisans hatası aldınız!</h2><br><br>
    <h3>Bu hatayı neden aldınız?</h3>
    <h4>Alan-adınız yasaklanmıştır.</h4>
</center>
</body>
</html>
                ");
        }
    }
}
?></textarea></p>
<?php
}else{
?>
<p><textarea onclick="this.focus();this.select()" class="form-control" rows="12" readonly="" style="display: inline;">&lt;?php 
function get_custom_date($timezone = "UTC", $format = "d.m.Y, H:i:s") {
 $dt = new DateTime("now", new DateTimeZone($timezone));
 $dt->setTimestamp(time());
 return $dt->format($format);
 unset($timezone, $format, $dt);
}

$checker = file_get_contents('<?php echo $url; ?>api/checker.php?domain=' . $_SERVER["HTTP_HOST"] .''); //connected to checker
$trialstatus = file_get_contents('<?php echo $url; ?>api/trial.php?domain=' . $_SERVER["HTTP_HOST"] .''); //connected to trial checker

$json = json_decode($checker); //checkers JSON decoded
$json2 = json_decode($trialstatus); //trial JSON decoded

$mylisans_timezone = "Europe/Istanbul"; //timezone set
$bitisraw = $json->bitis; //got license ending
$bitisarray = explode("-", $bitisraw); //license ending exploded
$bitis = mktime(0, 0, 0, $bitisarray[1], $bitisarray[2], $bitisarray[0]); //$bitisarray turned into decimal
$tarih = mktime(0, 0, 0, get_custom_date($mylisans_timezone, "m") , get_custom_date($mylisans_timezone, "d") , get_custom_date($mylisans_timezone, "Y")); //todays date turned into decimal

$adsoyad = $json->adsoyad; //customers name got from JSON
$status = $json->status; //got license status from the JSON that encoded by license checker
$ban = $json->ban; //got the ban status od the specified domain
$durum = $json2->durum;

if (!$durum) {

if ($status == "error") {
	?>
  &lt;iframe width="0" frameborder="no" height="0" src="<?php echo $url; ?>api/ihbar.php?domain=&lt;?php echo $_SERVER['SERVER_NAME'] ?>">&lt;/iframe>
  &lt;?php
die("<!DOCTYPE html>
<html>
<head>
    <title>Lisans hatası!</title>
    <link href=\"https://fonts.googleapis.com/css?family=Didact+Gothic|Montserrat|Open+Sans+Condensed:300|Titillium+Web&display=swap\" rel=\"stylesheet\">
    <style type=\"text/css\">
        body {
            background-color: #FF3B3B;
            font-family: 'Didact Gothic', sans-serif;
            color: white;
        }
    </style>
</head>
<body>
<center>
    <br><br><br>
    <img width=\"215\" height=\"200\" src=\"https://img510.yukle.tc/images/6935alert.png\">
    <h2>Lisans hatası aldınız!</h2><br><br>
    <h3>Bu hatayı neden aldınız?</h3>
    <h4>Scripti lisanssız kurmuşsunuz. Lisans satın almanız gereklidir.</h4>
</center>
</body>
</html>");
}else{
	if ($bitis < $tarih) {
		die("
<!DOCTYPE html>
<html>
<head>
    <title>Lisans hatası!</title>
    <link href=\"https://fonts.googleapis.com/css?family=Didact+Gothic|Montserrat|Open+Sans+Condensed:300|Titillium+Web&display=swap\" rel=\"stylesheet\">
    <style type=\"text/css\">
        body {
            background-color: #FF3B3B;
            font-family: 'Didact Gothic', sans-serif;
            color: white;
        }
    </style>
</head>
<body>
<center>
    <br><br><br>
    <img width=\"215\" height=\"200\" src=\"https://img510.yukle.tc/images/6935alert.png\">
    <h2>Lisans hatası aldınız!</h2><br><br>
    <h3>Bu hatayı neden aldınız?</h3>
    <h4>Lisans süreniz dolmuştur. Yeni lisans almanız gereklidir.</h4>
</center>
</body>
</html>
            ");
	}else{
		if ($ban) {
			die("
<!DOCTYPE html>
<html>
<head>
    <title>Lisans hatası!</title>
    <link href=\"https://fonts.googleapis.com/css?family=Didact+Gothic|Montserrat|Open+Sans+Condensed:300|Titillium+Web&display=swap\" rel=\"stylesheet\">
    <style type=\"text/css\">
        body {
            background-color: #FF3B3B;
            font-family: 'Didact Gothic', sans-serif;
            color: white;
        }
    </style>
</head>
<body>
<center>
    <br><br><br>
    <img width=\"215\" height=\"200\" src=\"https://img510.yukle.tc/images/6935alert.png\">
    <h2>Lisans hatası aldınız!</h2><br><br>
    <h3>Bu hatayı neden aldınız?</h3>
    <h4>Alan-adınız yasaklanmıştır.</h4>
</center>
</body>
</html>
                ");
		}
	}
}
}
?></textarea></p>
<?php } ?>
					</div>
				</div>
			</div>
			
			</div><!--/.row-->
		</div>

			<div class="col-sm-12">
				<p class="back-link">Lumino Theme by <a href="https://www.medialoot.com">Medialoot</a></p>
			</div>
		</div><!--/.row-->
	</div>	<!--/.main-->
	
	<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/chart.min.js"></script>
	<script src="js/chart-data.js"></script>
	<script src="js/easypiechart.js"></script>
	<script src="js/easypiechart-data.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script src="js/custom.js"></script>
	<script>
		window.onload = function () {
	var chart1 = document.getElementById("line-chart").getContext("2d");
	window.myLine = new Chart(chart1).Line(lineChartData, {
	responsive: true,
	scaleLineColor: "rgba(0,0,0,.2)",
	scaleGridLineColor: "rgba(0,0,0,.05)",
	scaleFontColor: "#c5c7cc"
	});
};
	</script>
		
</body>
</html>