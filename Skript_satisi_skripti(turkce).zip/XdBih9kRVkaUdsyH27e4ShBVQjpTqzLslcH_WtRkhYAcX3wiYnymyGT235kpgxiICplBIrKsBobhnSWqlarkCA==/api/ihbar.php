<?php 
$domain = strip_tags($_GET['domain']);
include "../baglanti.php";
                    $kayit = $db->prepare("SELECT count(*) FROM ihbarlar WHERE ihbaralanadi=:durum");
                    $kayit->execute(array('durum' => $domain, ));
                    $say = $kayit->fetchColumn();
if ($say != 0) {

}else{
	$insert = $db->prepare("INSERT INTO ihbarlar (ihbaralanadi, sebep) VALUES (?, ?)");
$sebep = "Lisanssız kullanım";
$insert->execute(array($domain,$sebep));
}

 ?>