<?php 
header('Content-type: application/json');
include "../baglanti.php";
$domain = $_GET['domain'];

$lidatasor=$db->prepare("SELECT * FROM lisanslar WHERE domain=:domain");
$lidatasor->execute(array('domain' => $domain));
$lidatacek=$lidatasor->fetch(PDO::FETCH_ASSOC);

if (!empty($lidatacek['lidata'])) {
	echo $lidatacek['lidata'];
}else{
	echo json_encode(["status" => "error"]);
}
 ?>