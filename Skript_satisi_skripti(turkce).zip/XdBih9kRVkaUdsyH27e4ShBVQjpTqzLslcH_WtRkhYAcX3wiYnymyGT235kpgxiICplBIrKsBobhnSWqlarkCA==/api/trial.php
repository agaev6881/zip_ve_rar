<?php 
date_default_timezone_set('Europe/Istanbul');
$domain = strip_tags($_GET['domain']);
include "../baglanti.php";
$kayit = $db->prepare("SELECT count(*) FROM trials WHERE domain=:domain");
$kayit->execute(array('domain' => $domain, ));
$say = $kayit->fetchColumn();

$sure = $db->prepare("SELECT * FROM ayar");
$sure->execute();
$fetched = $sure->fetch();

if ($say == 0) {

$trialbaslangic = mktime(0, 0, 0, date("y")  , date("m"), date("d"));
$trialbitis  = mktime(0, 0, 0, date("y")  , date("m"), date("d")+$fetched['trialtime']);

$insert = $db->prepare("INSERT INTO trials (domain, trialbaslangic, trialbitis) VALUES (?, ?,?)");
$insert->execute(array($domain,$trialbaslangic,$trialbitis));
echo "{ \"durum\": true }";
}else{
	$sure = $db->prepare("SELECT * FROM trials WHERE domain=:domain");
	$sure->execute(array('domain' => $domain, ));
	$fetch = $sure->fetch();
	$bitis = $fetch['trialbitis'];
	$bugun = mktime(0, 0, 0, date("y")  , date("m"), date("d"));
	if ($bugun > $bitis) {
		echo "{ \"durum\": false }";
	}else{
		echo "{ \"durum\": true }";
	}
}

 ?>