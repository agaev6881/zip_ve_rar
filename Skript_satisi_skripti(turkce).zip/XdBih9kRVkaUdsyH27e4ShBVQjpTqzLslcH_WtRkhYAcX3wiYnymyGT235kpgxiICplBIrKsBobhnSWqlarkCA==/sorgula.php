<?php
include "baglanti.php";
            if($_POST){
              $domain=strip_tags($_POST["domain"]);
              if(!empty($domain)){
                $sorgu=$db->prepare("SELECT * FROM lisanslar WHERE domain=?");// sql yazarak verilerin doğruluğunu kontrol ediyoruz.
                $sorgu->execute(array($domain));//Kontrol edilecek olan değişkenleri yazdık
                $islem=$sorgu->fetch();// Burada sorguyu parcalayarak girilen bilgilerin karşılığı varmı dedik

                if($islem){
                  $_SESSION['kod'] = $islem['kod'];
?>
  <div>
			<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
			<script type="text/javascript">
				Swal.fire({
  icon: 'success',
  title: 'Lisans geçerli',
  text: 'Lisans başarıyla doğrulandı.',
  showConfirmButton: false
})

			</script>
			</div>
        <?php
      }
      else//Eğer girilen bilgiler eşleşmiyorsa
      {
      	 $kayit = $db->prepare("SELECT count(*) FROM ihbarlar WHERE ihbaralanadi=:durum");
                    $kayit->execute(array('durum' => $domain, ));
                    $say = $kayit->fetchColumn();
if ($say != 0) {

}else{
	$insert = $db->prepare("INSERT INTO ihbarlar (ihbaralanadi, sebep) VALUES (?, ?)");
$sebep = "Lisanssız kullanım";
$insert->execute(array(strip_tags($domain),$sebep));
}
        ?>
       <div>
			<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
			<script type="text/javascript">
				Swal.fire({
  icon: 'error',
  title: 'Lisans geçersiz',
  text: 'Lisans doğrulanamadı. İhbar edildi.',
  showConfirmButton: false
})

			</script>
			</div>
        <?php
      }
    }
    else//Eğer alanlar boş ise ekranda yazıcak olan kısım.
    {
     ?>
     <div>
			<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
			<script type="text/javascript">
				Swal.fire({
  icon: 'error',
  title: 'Maalesef!',
  text: 'Boş alan bırakmayın.',
  showConfirmButton: false
})

			</script>
			</div>
			<?php
		}}
		?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Lisans Sorgula</title>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/datepicker3.css" rel="stylesheet">
	<link href="css/styles.css" rel="stylesheet">
	<!--[if lt IE 9]>
	<script src="js/html5shiv.js"></script>
	<script src="js/respond.min.js"></script>
	<![endif]-->
	 <style type="text/css">
					.swal2-popup {
  font-size: 1.6rem !important;
}

				</style>
</head>
<body>
	<div class="row">
		<div class="col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2 col-md-4 col-md-offset-4">
			<div class="login-panel panel panel-default">
				<div class="panel-heading">Lisans Sorgulama</div>
				<div class="panel-body">
					<form action="" method="POST" role="form">
						<fieldset>
							<div class="form-group">
								<input class="form-control" placeholder="Sorgulanacak alan-adı" name="domain" required="" type="text" autofocus="">
							</div>
							<button type="submit" class="btn btn-primary">Sorgula</button></fieldset>
					</form>
				</div>
			</div>
		</div><!-- /.col-->
	</div><!-- /.row -->	
	

<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
</body>
</html>
