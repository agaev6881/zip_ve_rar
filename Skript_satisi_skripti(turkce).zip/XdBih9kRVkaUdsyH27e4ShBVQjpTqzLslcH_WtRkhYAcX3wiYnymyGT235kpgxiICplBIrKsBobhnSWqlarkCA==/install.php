<?php

if(file_exists('baglanti.php')){
  die("Kurulum zaten yapilmis!");
}
else{

$sifre = $_POST['sifre'];
$sifremd5 = md5($sifre);

  if ($_POST){
    
    $host = $_POST["host"];
    $username = $_POST["username"];
    $pass = $_POST["pass"];
    $veritabani = $_POST["db"];
    $adsoyad = $_POST["adsoyad"];
    $eposta = $_POST["eposta"];

    try {

$sql = "
CREATE TABLE `lisanslar` (
  `id` int(11) NOT NULL,
  `musteri` varchar(255) NOT NULL,
  `ban` int(11) NOT NULL DEFAULT '1',
  `bitis` varchar(255) DEFAULT NULL,
  `lidata` varchar(255) DEFAULT NULL,
  `domain` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

ALTER TABLE `lisanslar`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `lisanslar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
";
$sql2 = "
CREATE TABLE `uye` (
  `id` int(11) NOT NULL,
  `adsoyad` varchar(255) NOT NULL,
  `eposta` varchar(255) NOT NULL,
  `sifre` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

ALTER TABLE `uye`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `uye`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

INSERT INTO `uye` (`id`, `adsoyad`, `eposta`, `sifre`) VALUES
(1, '$adsoyad', '$eposta', '$sifremd5');
";
$sql3 = "
CREATE TABLE `ihbarlar` (
  `id` int(11) NOT NULL,
  `ihbaralanadi` varchar(255) NOT NULL,
  `sebep` varchar(255) NOT NULL DEFAULT 'Lisanssız kullanım bildirimi'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

ALTER TABLE `ihbarlar`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `ihbarlar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;
";

$sql4 = "
CREATE TABLE `ayar` (
  `id` int(11) NOT NULL DEFAULT '1',
  `trialtime` varchar(64) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `ayar` (`id`, `trialtime`) VALUES
(1, '0');
";

$sql5 = "
CREATE TABLE `trials` (
  `id` int(11) NOT NULL,
  `domain` varchar(255) NOT NULL,
  `trialbaslangic` varchar(255) DEFAULT NULL,
  `trialbitis` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

ALTER TABLE `trials`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `trials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
";

         $db = new PDO("mysql:host=$host;dbname=$veritabani;charset=utf8", "$username", "$pass");
         $db->query($sql);
         $db->query($sql2);
         $db->query($sql3);
         $db->query($sql4);
         $db->query($sql5);

    } catch ( PDOException $e ){

        ?>
        <div>
      <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
      <script type="text/javascript">swal("Kurulum tamamlanamadı!", "MySQL veritabanına bağlanılamadı!", "success");
      </script>
      </div>  
        <?php

        header("refresh:3;url=install.php");

    }
    if($db){

      $olustur = touch("baglanti.php");

      if($olustur){
        $ac     = fopen('baglanti.php', 'w');
        $icerik = '
<?php

// MyLisans veritabanı bağlantı sayfasıdır. Dokunmayınız.

$host = "'.$host.'"; //sunucu
$kullanici = "'.$username.'"; //kullanici adi
$sifre = "'.$pass.'"; //sifre
$db = "'.$veritabani.'";//veritabani ismi 

try {
     $db = new PDO("mysql:host=$host;dbname=$db;charset=utf8", "$kullanici", "$sifre");
} catch ( PDOException $e ){
     print $e->getMessage();
}

?>
';

        $kaydet = fwrite($ac, $icerik);

        ?>
       <!DOCTYPE html>
<html>
  <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    
    <title>MyLisans - Kurulum</title>
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.1/css/bulma.css" />
    <style type="text/css">
    body, html {
    background: #F7F7F7;
    }
    </style>
  </head>
  <body>
    <div class="container main_body"> <div class="section" >
      <div class="column is-6 is-offset-3">
        <center><h1 class="title" style="padding-top: 20px">
        MyLisans | Kurulum
        </h1><br></center>
        <div class="box">
            <div class="notification is-success"><b>BAŞARILI!</b> MyLisans başarıyla kuruldu. İyi kullanımlar.</div>
</body>
</html>
        <?php

        header("refresh:2;url=index.php");


      }

    


  }else{
    header("Location: install.php");
  }
}else{

?>
<!DOCTYPE html>
<html>
  <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    
    <title>MyCraft - Kurulum</title>
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.1/css/bulma.css" />
    <style type="text/css">
    body, html {
    background: #F7F7F7;
    }
    </style>
  </head>
  <body>
    <div class="container main_body"> <div class="section" >
      <div class="column is-6 is-offset-3">
        <center><h1 class="title" style="padding-top: 20px">
        MyLisans | Kurulum
        </h1><br></center>
        <div class="box">
          <form action="" method="POST">
            <div class="notification is-primary">MyLisans kurulumuna hoşgeldiniz!</div>
            <div class="field">
              <label class="label">MySQL Sunucu (HOST)</label>
              <div class="control">
                <input class="input" type="text" placeholder="MySQL sunucu adresiniz." name="host" required>
              </div>
            </div>
            <div class="field">
              <label class="label">MySQL Kullanıcı Adı</label>
              <div class="control">
                <input class="input" type="text" placeholder="MySQL kullanıcı adınız." name="username" required>
              </div>
            </div>
            <div class="field">
              <label class="label">MySQL Veritabanı Adı</label>
              <div class="control">
                <input class="input" type="text" placeholder="MySQL veritabanınızın adı." name="db" required>
              </div>
            </div>
            <div class="field">
              <label class="label">MySQL Şifre</label>
              <div class="control">
                <input class="input" type="password" placeholder="MySQL sunucu şifreniz." name="pass" required>
              </div>
            </div>
            <hr>
            <div class="field">
              <label class="label">Admin Ad Soyad</label>
              <div class="control">
                <input class="input" type="text" placeholder="Adınız ve soyadınız" name="adsoyad" required>
              </div>
            </div>
            <div class="field">
              <label class="label">Admin E-Posta</label>
              <div class="control">
                <input class="input" type="text" name="eposta" required>
              </div>
            </div>
            <div class="field">
              <label class="label">Admin Şifresi</label>
              <div class="control">
                <input class="input" type="password" placeholder="İstediğiniz admin şifresini yazınız." name="sifre" required>
              </div>
            </div>
            <div style='text-align: right;'>
              <button type="submit" class="button is-link">Kurulumu Başlat</button>
            </div>
          </form>
<?php } } ?> 
</body>
</html>